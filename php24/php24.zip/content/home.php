<?php 
/**
 * home.php
 * 
 * Content for the home page
 * 
 *  @version    1.2 2011-02-03
 * @package    Smithside Auctions
 * @copyright  Copyright (c) 2011 Smithside Auctions
 * @license    GNU General Public License
 * @since      Since Release 1.0
 */
?>
<h1>Next Auction September 22nd</h1>
        <p>Join us for our next auction of historic clothing
         to be held at the St. Paul's Auditorium in NYC on September 22nd at 1 o'clock.</p>
        
        <p>Lots can be viewed the prior day from 4pm until 7pm and again on Thursday morning from
         10am to noon.</p>
         